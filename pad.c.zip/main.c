#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main()
{
     int a,i,n=0;
    scanf("%d",&a);
    for(i=1;i<a;i++)
    {
        if(a%i==0)
        {
            n=n+i;
        }
    }
    if(n==a){
        printf("Perfect Number");
    }
    else if(n>a){
        printf("Abundant Number");
    }
    else{
        printf("Deficient Number");
    }
   return 0;
}
