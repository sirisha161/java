import java.util.Scanner;
interface Father{
    void getFatherDetails(Scanner sc);
    void showFatherDetails();
}
interface Mother{
    void getMotherDetails(Scanner sc);
    void showMotherDetails();
}
class Child implements Father, Mother{
    String fatherName, motherName, childAge;
    String fatherJob, motherJob, childHobby;
    public void getFatherDetails(Scanner sc){
        fatherName=sc.nextLine();
        fatherAge=Integer.parseInt(sc.nextLine());
        fatherJob=sc.nextLine();
    }
    public void showFatherDetails(){
        System.out.println("Father:"+ fatherName +"| Age:"+fatherAge+ "|Profession:"+fatherJob);
    }
    public void getMotherDetails(Scanner sc){
        motherName=sc.nextLine();
        motherAge=Integer.parseInt(sc.nextLine());
        motherJob=sc.nextLine();
    }
    public  void showMotherDetails(Scanner sc){
        System.out.println("Mother:"+ motherName +"| Age:"+motherAge+ "|Profession:"+motherJob);
    }
    public void getChildDetails(Scanner sc){
        childName=sc.nextLine();
        childAge=Integer.parseInt(sc.nextLine());
        childHobby=sc.nextLine();
    }
    public void showChildDetails(){
        System.out.println("Child:"+ childName +"| Age:"+childAge+ "|Profession:"+childHobby);
    }
    public class multi{
        public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            Child c=new Child();
            System.out.println("Enter father details----");
            c.getFatherDetails(sc);
            System.out.println("Enter mother details----");
            c.getMotherDetails(sc);
             System.out.println("Enter child details----");
            c.getChildDetails(sc);
            System.out.println("\n-----Family details----");
            c.showFatherDetails();
            c.showMotherDetails();
            c.showChildDetails();
            sc.close();
        }
    }  
}    