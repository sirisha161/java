import java.util.Scanner;

class InputNumbers {
    int a, b;

    void getInput(Scanner sc) {
        a = sc.nextInt();
        b = sc.nextInt();
    }
}

class PowerCal extends InputNumbers {
    void power() {
        int result = 1;
        for (int i = 0; i < b; i++) {  // Fixed loop condition
            result *= a;
        }
        System.out.println("Power(" + a + "^" + b + "): " + result);
    }
}

class FactorialCal extends PowerCal {
    int factorial(int n) {
        int fact = 1;
        for (int i = 1; i <= n; i++) {
            fact *= i;
        }
        return fact; // Corrected placement
    }

    void ShowFactorial() {
        System.out.println("Factorial of " + a + ": " + factorial(a));
        System.out.println("Factorial of " + b + ": " + factorial(b));
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        FactorialCal obj = new FactorialCal();
        obj.getInput(sc);
        System.out.println();
        obj.power();
        obj.ShowFactorial();
        sc.close();
    }
}
