import java.util.Scanner;
class Vehicle{
    private String model;
    private int speed;
    private final int MAX_SPEED=120;
    public Vehicle(String model){
        this.model=model;
        this.speed=0;
    }
    public int getSpeed(){
        return speed;
    }
    public void accelerate(int increment){
        if(speed +increment<=MAX_SPEED){
            speed+=increment;
            System.out.println("Increased speed by"+increment+ "km/h");
        }else{
            speed=MAX_SPEED;
            System.out.print("Reached Maximum speed to "+MAX_SPEED+ "km/h");
        }
    }
    public void brake(int decrement){
        if(speed -decrement>=0){
            speed-=decrement;
            System.out.println("Brake by"+decrement+"km/h");
        }
        else{
            speed=0;
            System.out.print("Vehicle stopped");
        }
    }
    public String getmodel(){
        return model;
    }
}
    public class VehicleDemo{
        public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter model name : ");
            String model=sc.nextLine();
            Vehicle car=new Vehicle(model);
            System.out.print("Current speed " +car.getSpeed()+"km/h\n");
            System.out.print("Enter speed to accelerate ");
            int acc=sc.nextInt();
            car.accelerate(acc);
            System.out.print("Currnt speed "+car.getSpeed()+"km/h\n");
            System.out.print("Enter speed to brake ");
            int brake=sc.nextInt();
            car.brake(brake);
            System.out.print("Current speed "+car.getSpeed()+"km/h");
            sc.close();
        }
    }