#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a,t,rem=0;
    scanf("%d",&a);
    t=a;
    while(a>0){
        rem=rem+a%10;
        rem=rem*10;
        a=a/10;
    }
    rem=rem/10;
    if(rem==t){
        printf("Palindrome");
    }
    else{
        printf("Not a Palindrome");
    }
    
    return 0;
}
