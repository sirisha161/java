#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int n,i,sum=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        if(i%2==0){
            sum=sum+i;
        }
    }
    printf("%d",sum);
    return 0;
}
