import java.util.Scanner;
class MathOperatins{
    int add(int a, int b){
        return a+b;
    }
    double add(double a, double b){
        return a+b;
    }
    int add(int a, int b, int c){
        return a+b+c;
    }
}
public class poly{
    public static void main(String[] args){
        MathOperatins mo=new MathOperatins();
        System.out.println();;(10, 20);
        System.out.println(2.4, 3.4);
        System.out.println(10, 20, 30);
    }
}