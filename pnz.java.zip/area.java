import java.util.Scanner;
public class area{
    public static void main(string[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter the radius value:");
        double radius=scanner.nextDouble();
        double area=math.PI*radius*radius;
        System.out.println("The area fo the circle with radius %.2f is: %.2f\n",radius,area);
        scanner.close();
    }
}