#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int amount;
    int notes[]={500,100,50,20,10,5,2,1};
    int count[8]={0};
    scanf("%d",&amount);
    for(int i=0;i<8;i++){
        if(amount>=notes[i]){
            count[i]=amount/notes[i];
            amount-=count[i]*notes[i];
        }
    }
    printf("Total number of notes:\n");
    for(int i=0;i<8;i++){
        printf("%d : %d\n",notes[i],count[i]);
    }
    return 0;
}